-- Bronzebeard Regrouper - WoW 3.3.5a compatible
-- UI controlled party save / leave / reinvite helper

local ADDON = "BronzebeardRegrouper"
local BRG = CreateFrame("Frame", "BronzebeardRegrouperCore")
local DB
local inviteQueue = {}
local inviteIndex = 1
local inviteTimer = 0
local INVITE_DELAY = 1.45
local isRegrouping = false
local pendingRegroup = false
local leaveWait = 0

local function trim(s)
    if not s then return "" end
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function normName(name)
    name = trim(name or "")
    if name == "" then return nil end
    return name:gsub("%s+", "")
end

local function playerFullName()
    local n, r = UnitName("player")
    return n or "player"
end

local function ensureDB()
    BronzebeardRegrouperDB = BronzebeardRegrouperDB or {}
    BronzebeardRegrouperDB.players = BronzebeardRegrouperDB.players or {}
    BronzebeardRegrouperDB.minimized = BronzebeardRegrouperDB.minimized or false
    DB = BronzebeardRegrouperDB
end

local function containsPlayer(name)
    if not DB then ensureDB() end
    local lower = string.lower(name or "")
    for i, v in ipairs(DB.players) do
        if string.lower(v) == lower then return i end
    end
    return nil
end

local function setStatus(msg, r, g, b)
    if BRG.statusText then
        BRG.statusText:SetText(msg or "")
        BRG.statusText:SetTextColor(r or 0.85, g or 0.85, b or 0.85)
    end
    DEFAULT_CHAT_FRAME:AddMessage("|cffcd7f32BRG:|r " .. (msg or ""), r or 0.85, g or 0.85, b or 0.85)
end

local function refreshList()
    if not BRG.rows then return end
    FauxScrollFrame_Update(BRG.scrollFrame, #DB.players, 8, 28)
    local offset = FauxScrollFrame_GetOffset(BRG.scrollFrame)
    for i = 1, 8 do
        local row = BRG.rows[i]
        local idx = i + offset
        if DB.players[idx] then
            row.index = idx
            row.nameText:SetText(DB.players[idx])
            row:Show()
            if idx % 2 == 0 then row.bg:SetVertexColor(0.12, 0.10, 0.08, 0.50) else row.bg:SetVertexColor(0.20, 0.15, 0.10, 0.45) end
        else
            row.index = nil
            row:Hide()
        end
    end
    if BRG.countText then
        BRG.countText:SetText("Gespeichert: " .. tostring(#DB.players) .. "/4")
    end
end

local function addPlayer(name, silent)
    name = normName(name)
    if not name then
        if not silent then setStatus("Kein Spielername eingegeben.", 1, 0.35, 0.25) end
        return false
    end
    if string.lower(name) == string.lower(playerFullName()) then
        if not silent then setStatus("Dich selbst speichere ich nicht.", 1, 0.55, 0.25) end
        return false
    end
    if containsPlayer(name) then
        if not silent then setStatus(name .. " ist bereits gespeichert.", 1, 0.82, 0.25) end
        return false
    end
    if #DB.players >= 4 then
        if not silent then setStatus("Eine 5er-Gruppe hat maximal 4 andere Spieler.", 1, 0.35, 0.25) end
        return false
    end
    table.insert(DB.players, name)
    refreshList()
    if not silent then setStatus(name .. " hinzugefügt.", 0.45, 1, 0.45) end
    return true
end

local function removePlayerAt(index)
    if index and DB.players[index] then
        local n = DB.players[index]
        table.remove(DB.players, index)
        refreshList()
        setStatus(n .. " entfernt.", 1, 0.75, 0.35)
    end
end

local function clearPlayers()
    DB.players = {}
    refreshList()
    setStatus("Liste geleert.", 1, 0.75, 0.35)
end

local function saveCurrentGroup()
    local count = 0
    DB.players = {}
    for i = 1, 4 do
        if UnitExists("party" .. i) then
            local name = UnitName("party" .. i)
            if name and name ~= "Unknown" then
                table.insert(DB.players, name)
                count = count + 1
            end
        end
    end
    refreshList()
    if count == 0 then
        setStatus("Keine Gruppenmitglieder gefunden.", 1, 0.55, 0.25)
    else
        setStatus("Aktuelle Gruppe gespeichert: " .. count .. " Spieler.", 0.45, 1, 0.45)
    end
end

local function startInvites()
    inviteQueue = {}
    for _, name in ipairs(DB.players) do
        if name and name ~= "" then table.insert(inviteQueue, name) end
    end
    inviteIndex = 1
    inviteTimer = 0.1
    isRegrouping = true
    if #inviteQueue == 0 then
        isRegrouping = false
        setStatus("Liste ist leer. Speichere oder füge Spieler hinzu.", 1, 0.35, 0.25)
    else
        setStatus("Einladungen starten...", 0.55, 0.85, 1)
    end
end

local function regroup()
    if #DB.players == 0 then
        setStatus("Liste ist leer. Erst Gruppe speichern oder Spieler hinzufügen.", 1, 0.35, 0.25)
        return
    end
    if UnitInParty("player") or GetNumPartyMembers() > 0 or GetNumRaidMembers() > 0 then
        pendingRegroup = true
        leaveWait = 1.0
        LeaveParty()
        setStatus("Gruppe verlassen, danach werden Spieler eingeladen...", 0.55, 0.85, 1)
    else
        startInvites()
    end
end

local function makeButton(parent, name, text, w, h)
    local b = CreateFrame("Button", name, parent, "UIPanelButtonTemplate")
    b:SetWidth(w or 110)
    b:SetHeight(h or 24)
    b:SetText(text)
    return b
end

local function createUI()
    local f = CreateFrame("Frame", "BronzebeardRegrouperFrame", UIParent)
    BRG.frame = f
    f:SetWidth(370)
    f:SetHeight(380)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    f:SetFrameStrata("DIALOG")
    f:Hide()

    f.bg = f:CreateTexture(nil, "BACKGROUND")
    f.bg:SetAllPoints(f)
    f.bg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background-Dark")

    f.border = CreateFrame("Frame", nil, f)
    f.border:SetPoint("TOPLEFT", -12, 12)
    f.border:SetPoint("BOTTOMRIGHT", 12, -12)
    f.border:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 16, edgeSize = 32,
        insets = { left = 10, right = 10, top = 10, bottom = 10 }
    })
    f.border:SetBackdropColor(0.03, 0.025, 0.02, 0.92)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -18)
    title:SetText("|cffcd7f32Bronzebeard Regrouper|r")

    local subtitle = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("TOP", title, "BOTTOM", 0, -4)
    subtitle:SetText("Gruppe speichern · verlassen · wieder einladen")

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    local panel = CreateFrame("Frame", nil, f)
    panel:SetPoint("TOPLEFT", 22, -62)
    panel:SetPoint("BOTTOMRIGHT", -22, 52)
    panel:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 12, insets = {left=4,right=4,top=4,bottom=4} })
    panel:SetBackdropColor(0.08, 0.06, 0.04, 0.88)
    panel:SetBackdropBorderColor(0.65, 0.42, 0.18, 0.85)

    BRG.countText = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    BRG.countText:SetPoint("TOPLEFT", 14, -12)
    BRG.countText:SetText("Gespeichert: 0/4")

    local edit = CreateFrame("EditBox", "BronzebeardRegrouperEditBox", panel, "InputBoxTemplate")
    BRG.editBox = edit
    edit:SetWidth(170)
    edit:SetHeight(24)
    edit:SetPoint("TOPLEFT", 14, -38)
    edit:SetAutoFocus(false)
    edit:SetTextInsets(4, 4, 0, 0)
    edit:SetScript("OnEnterPressed", function(self) addPlayer(self:GetText()); self:SetText(""); self:ClearFocus() end)

    local add = makeButton(panel, nil, "Hinzufügen", 100, 24)
    add:SetPoint("LEFT", edit, "RIGHT", 12, 0)
    add:SetScript("OnClick", function() addPlayer(edit:GetText()); edit:SetText("") end)

    local listBg = CreateFrame("Frame", nil, panel)
    listBg:SetPoint("TOPLEFT", 14, -74)
    listBg:SetWidth(292)
    listBg:SetHeight(226)
    listBg:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile=true, tileSize=16, edgeSize=10, insets={left=3,right=3,top=3,bottom=3} })
    listBg:SetBackdropColor(0.02, 0.018, 0.015, 0.75)
    listBg:SetBackdropBorderColor(0.40, 0.28, 0.13, 0.8)

    local scroll = CreateFrame("ScrollFrame", "BronzebeardRegrouperScrollFrame", listBg, "FauxScrollFrameTemplate")
    BRG.scrollFrame = scroll
    scroll:SetPoint("TOPLEFT", 4, -4)
    scroll:SetPoint("BOTTOMRIGHT", -28, 4)
    scroll:SetScript("OnVerticalScroll", function(self, offset) FauxScrollFrame_OnVerticalScroll(self, offset, 28, refreshList) end)

    BRG.rows = {}
    for i = 1, 8 do
        local row = CreateFrame("Frame", nil, listBg)
        row:SetWidth(256)
        row:SetHeight(26)
        row:SetPoint("TOPLEFT", 8, -6 - (i-1)*28)
        row.bg = row:CreateTexture(nil, "BACKGROUND")
        row.bg:SetAllPoints(row)
        row.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetWidth(18); row.icon:SetHeight(18)
        row.icon:SetPoint("LEFT", 6, 0)
        row.icon:SetTexture("Interface\\GroupFrame\\UI-Group-LeaderIcon")
        row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        row.nameText:SetPoint("LEFT", row.icon, "RIGHT", 8, 0)
        row.remove = CreateFrame("Button", nil, row, "UIPanelCloseButton")
        row.remove:SetWidth(22); row.remove:SetHeight(22)
        row.remove:SetPoint("RIGHT", -2, 0)
        row.remove:SetScript("OnClick", function(self) removePlayerAt(self:GetParent().index) end)
        BRG.rows[i] = row
    end

    local save = makeButton(f, nil, "Gruppe speichern", 132, 26)
    save:SetPoint("BOTTOMLEFT", 24, 18)
    save:SetScript("OnClick", saveCurrentGroup)

    local regroupBtn = makeButton(f, nil, "Regroup", 92, 26)
    regroupBtn:SetPoint("LEFT", save, "RIGHT", 8, 0)
    regroupBtn:SetScript("OnClick", regroup)

    local clear = makeButton(f, nil, "Liste leeren", 104, 26)
    clear:SetPoint("LEFT", regroupBtn, "RIGHT", 8, 0)
    clear:SetScript("OnClick", clearPlayers)

    BRG.statusText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    BRG.statusText:SetPoint("BOTTOM", 0, 48)
    BRG.statusText:SetWidth(320)
    BRG.statusText:SetJustifyH("CENTER")
    BRG.statusText:SetText("Bereit.")

    refreshList()
end

local function toggleUI()
    if not BRG.frame then createUI() end
    if BRG.frame:IsShown() then BRG.frame:Hide() else BRG.frame:Show(); refreshList() end
end

BRG:SetScript("OnUpdate", function(self, elapsed)
    if pendingRegroup then
        leaveWait = leaveWait - elapsed
        if leaveWait <= 0 and not UnitInParty("player") and GetNumPartyMembers() == 0 and GetNumRaidMembers() == 0 then
            pendingRegroup = false
            startInvites()
        elseif leaveWait <= -3 then
            pendingRegroup = false
            startInvites()
        end
    end

    if isRegrouping and inviteIndex <= #inviteQueue then
        inviteTimer = inviteTimer - elapsed
        if inviteTimer <= 0 then
            local name = inviteQueue[inviteIndex]
            InviteUnit(name)
            setStatus("Einladung: " .. name .. " (" .. inviteIndex .. "/" .. #inviteQueue .. ")", 0.55, 0.85, 1)
            inviteIndex = inviteIndex + 1
            inviteTimer = INVITE_DELAY
        end
    elseif isRegrouping and inviteIndex > #inviteQueue then
        isRegrouping = false
        setStatus("Regroup abgeschlossen.", 0.45, 1, 0.45)
    end
end)

BRG:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        ensureDB()
        createUI()
        SLASH_BRONZEBEARDREGROUPER1 = "/brg"
        SLASH_BRONZEBEARDREGROUPER2 = "/regroup"
        SlashCmdList["BRONZEBEARDREGROUPER"] = function(msg)
            toggleUI()
        end
    end
end)
BRG:RegisterEvent("ADDON_LOADED")
